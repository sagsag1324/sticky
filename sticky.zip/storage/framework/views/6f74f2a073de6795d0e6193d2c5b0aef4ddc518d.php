<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Sticky</title>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/app-bootstrap.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/app-main.css')); ?>" rel="stylesheet">

</head>

<body class="container-fluid m-0">
    <div class="home-container row"
        style="background-image: url(<?php echo e(asset('assets/main-page/full-background.png')); ?> );background-size:cover">
        <div class="col-6"></div>
        <div class="col-6">
            <div class="top-header">
                <?php if (isset($component)) { $__componentOriginal8966a23ff1ea305b8f20409a8949edc5490562c4 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\TopButton::class, ['text' => 'whatsapp','color' => 'color-1']); ?>
<?php $component->withName('top-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8966a23ff1ea305b8f20409a8949edc5490562c4)): ?>
<?php $component = $__componentOriginal8966a23ff1ea305b8f20409a8949edc5490562c4; ?>
<?php unset($__componentOriginal8966a23ff1ea305b8f20409a8949edc5490562c4); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginal8966a23ff1ea305b8f20409a8949edc5490562c4 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\TopButton::class, ['text' => 'instagram','color' => 'color-2']); ?>
<?php $component->withName('top-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8966a23ff1ea305b8f20409a8949edc5490562c4)): ?>
<?php $component = $__componentOriginal8966a23ff1ea305b8f20409a8949edc5490562c4; ?>
<?php unset($__componentOriginal8966a23ff1ea305b8f20409a8949edc5490562c4); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginal8966a23ff1ea305b8f20409a8949edc5490562c4 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\TopButton::class, ['text' => 'facebook','color' => 'color-3']); ?>
<?php $component->withName('top-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8966a23ff1ea305b8f20409a8949edc5490562c4)): ?>
<?php $component = $__componentOriginal8966a23ff1ea305b8f20409a8949edc5490562c4; ?>
<?php unset($__componentOriginal8966a23ff1ea305b8f20409a8949edc5490562c4); ?>
<?php endif; ?>
            </div>
            <div class="main-content">
                <img class="main-logo" src="<?php echo e(asset('assets/main-page/big-logo.png')); ?>" alt="">
                <div class="main-buttons-container">
                    <div class="regular-buttons-container mt-3">
                        <?php if (isset($component)) { $__componentOriginalb037b51008f1f163ca213b19824ab8547e21781f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\RegularButton::class, ['text' => 'Our Art']); ?>
<?php $component->withName('regular-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb037b51008f1f163ca213b19824ab8547e21781f)): ?>
<?php $component = $__componentOriginalb037b51008f1f163ca213b19824ab8547e21781f; ?>
<?php unset($__componentOriginalb037b51008f1f163ca213b19824ab8547e21781f); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginalb037b51008f1f163ca213b19824ab8547e21781f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\RegularButton::class, ['text' => 'Choose Your Style']); ?>
<?php $component->withName('regular-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb037b51008f1f163ca213b19824ab8547e21781f)): ?>
<?php $component = $__componentOriginalb037b51008f1f163ca213b19824ab8547e21781f; ?>
<?php unset($__componentOriginalb037b51008f1f163ca213b19824ab8547e21781f); ?>
<?php endif; ?>
                    </div>
                </div>
                <div class="main-text-style text-center text-light text-bold mt-3">
                    <div>
                        A brand designed QR code attracts customers
                    </div>
                    <div>
                        to quickly and easily access your website,
                    </div>
                    <div>
                        social media, or online ordering system.
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row carousel-container">
        <?php if (isset($component)) { $__componentOriginalcbfad8957ccb413913979399db567f18cf2d7919 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Carousel::class, []); ?>
<?php $component->withName('carousel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcbfad8957ccb413913979399db567f18cf2d7919)): ?>
<?php $component = $__componentOriginalcbfad8957ccb413913979399db567f18cf2d7919; ?>
<?php unset($__componentOriginalcbfad8957ccb413913979399db567f18cf2d7919); ?>
<?php endif; ?>
    </div>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\sticky\resources\views/home.blade.php ENDPATH**/ ?>