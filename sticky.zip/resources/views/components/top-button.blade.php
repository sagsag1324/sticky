<span class="neon-button">
    <a href="#" @class(['neon-button', 'neon-color-1' => $color === 'color-1', 'neon-color-2' => $color === 'color-2'])>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        {{$text}}
    </a>
</span>
