<span class="neon-button">
    <a href="#" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['neon-button', 'neon-color-1' => $color === 'color-1', 'neon-color-2' => $color === 'color-2']) ?>">
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <?php echo e($text); ?>

    </a>
</span>
<?php /**PATH C:\xampp\htdocs\sticky\resources\views/components/top-button.blade.php ENDPATH**/ ?>