<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Sticky</title>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">

    <!-- Styles -->
    <link href="{{ asset('css/app.css') }}" rel="stylesheet">
    <link href="{{ asset('css/app-bootstrap.css') }}" rel="stylesheet">
    <link href="{{ asset('css/app-main.css') }}" rel="stylesheet">

</head>

<body class="container-fluid m-0">
    <div class="home-container row"
        style="background-image: url({{ asset('assets/main-page/full-background.png') }} );background-size:cover">
        <div class="col-6"></div>
        <div class="col-6">
            <div class="top-header">
                <x-top-button :text="'whatsapp'" :color="'color-1'" />
                <x-top-button :text="'instagram'" :color="'color-2'" />
                <x-top-button :text="'facebook'" :color="'color-3'" />
            </div>
            <div class="main-content">
                <img class="main-logo" src="{{ asset('assets/main-page/big-logo.png') }}" alt="">
                <div class="main-buttons-container">
                    <div class="regular-buttons-container mt-3">
                        <x-regular-button :text="'Our Art'"></x-regular-button>
                        <x-regular-button :text="'Choose Your Style'"></x-regular-button>
                    </div>
                </div>
                <div class="main-text-style text-center text-light text-bold mt-3">
                    <div>
                        A brand designed QR code attracts customers
                    </div>
                    <div>
                        to quickly and easily access your website,
                    </div>
                    <div>
                        social media, or online ordering system.
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row carousel-container">
        <x-carousel></x-carousel>
    </div>
</body>

</html>
