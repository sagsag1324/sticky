<span class="regular-button-container mx-3">
    <button class="custom-btn btn-6"><span><?php echo e($text); ?></span></button>
</span>
<?php /**PATH C:\xampp\htdocs\sticky\resources\views/components/regular-button.blade.php ENDPATH**/ ?>