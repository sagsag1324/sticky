<span class="regular-button-container mx-3">
    <button class="custom-btn btn-6"><span>{{$text}}</span></button>
</span>
